#!/bin/bash
set -e
sudo systemctl start tomcat
